import { useState, useRef, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
  ArrowLeft, Save, FileText, Phone, Users, BookOpen, Shield, Palette,
  Upload, Trash2, LogOut, Loader2, Image as ImageIcon, Plus, Baby
} from "lucide-react";
import KidsSection from "@/components/admin/KidsSection";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

// Helper to safely construct Armenian strings
const arm = (...codes: number[]) => String.fromCharCode(...codes);

const sections = [
  { id: "hero", label: arm(0x0533, 0x056C, 0x056D, 0x0561, 0x057E, 0x0578, 0x0580, 0x20, 0x0567, 0x057B), icon: FileText },
  { id: "about", label: arm(0x0544, 0x0565, 0x0580, 0x20, 0x0574, 0x0561, 0x057D, 0x056B, 0x0576), icon: BookOpen },
  { id: "programs", label: arm(0x053E, 0x0580, 0x0561, 0x0563, 0x0580, 0x0565, 0x0580), icon: Users },
  { id: "activities", label: arm(0x0533, 0x0578, 0x0580, 0x056E, 0x0578, 0x0582, 0x0576, 0x0565, 0x0578, 0x0582, 0x0569, 0x0575, 0x0578, 0x0582, 0x0576), icon: Palette },
  { id: "safety", label: arm(0x0531, 0x0576, 0x057E, 0x057F, 0x0561, 0x0576, 0x0563, 0x0578, 0x0582, 0x0569, 0x0575, 0x0578, 0x0582, 0x0576), icon: Shield },
  { id: "contact", label: arm(0x053F, 0x0561, 0x057A), icon: Phone },
  { id: "gallery", label: arm(0x054A, 0x0561, 0x057F, 0x056F, 0x0565, 0x0580, 0x0561, 0x057D, 0x0580, 0x0561, 0x0570), icon: ImageIcon },
  { id: "metas", label: "SEO / Meta", icon: FileText },
  { id: "kids", label: arm(0x0535, 0x0580, 0x0565, 0x056D, 0x0561, 0x0576, 0x0565, 0x0580), icon: Baby },
];

// Field labels for each section
const fieldLabels: Record<string, Record<string, string>> = {
  hero: {
    title: arm(0x054E, 0x0565, 0x0580, 0x0576, 0x0561, 0x0563, 0x056B, 0x0580),
    subtitle: arm(0x0535, 0x0576, 0x0569, 0x0561, 0x057E, 0x0565, 0x0580, 0x0576, 0x0561, 0x0563, 0x056B, 0x0580),
    description: arm(0x0546, 0x056F, 0x0561, 0x0580, 0x0561, 0x0563, 0x0580, 0x0578, 0x0582, 0x0569, 0x0575, 0x0578, 0x0582, 0x0576),
  },
  about: {
    text1: arm(0x054F, 0x0565, 0x0584, 0x057D, 0x057F) + " 1",
    text2: arm(0x054F, 0x0565, 0x0584, 0x057D, 0x057F) + " 2",
    feature1: arm(0x0540, 0x0561, 0x057F, 0x056F, 0x0561, 0x0576, 0x056B, 0x0577) + " 1 (❤️)",
    feature2: arm(0x0540, 0x0561, 0x057F, 0x056F, 0x0561, 0x0576, 0x056B, 0x0577) + " 2 (⭐)",
    feature3: arm(0x0540, 0x0561, 0x057F, 0x056F, 0x0561, 0x0576, 0x056B, 0x0577) + " 3 (🛡️)",
    feature4: arm(0x0540, 0x0561, 0x057F, 0x056F, 0x0561, 0x0576, 0x056B, 0x0577) + " 4 (✨)",
  },
  contact: {
    address: arm(0x0540, 0x0561, 0x057D, 0x0581, 0x0565),
    phone: arm(0x0540, 0x0565, 0x057C, 0x0561, 0x056D, 0x0578, 0x057D),
    email: arm(0x0537, 0x056C) + ". " + arm(0x0583, 0x0578, 0x057D, 0x057F),
  },
  programs: {
    small_group: arm(0x0553, 0x0578, 0x0584, 0x0580, 0x056B, 0x056F, 0x20, 0x056D, 0x0578, 0x0582, 0x0574, 0x0562) + " (2-3 " + arm(0x057F, 0x0561, 0x0580, 0x0565, 0x056F, 0x0561, 0x0576) + ")",
    middle_group: arm(0x0544, 0x056B, 0x057B, 0x056B, 0x0576, 0x20, 0x056D, 0x0578, 0x0582, 0x0574, 0x0562) + " (3-5 " + arm(0x057F, 0x0561, 0x0580, 0x0565, 0x056F, 0x0561, 0x0576) + ")",
    senior_group: arm(0x0531, 0x057E, 0x0561, 0x0563, 0x20, 0x056D, 0x0578, 0x0582, 0x0574, 0x0562) + " (5-6 " + arm(0x057F, 0x0561, 0x0580, 0x0565, 0x056F, 0x0561, 0x0576) + ")",
  },
  activities: {
    description: arm(0x0533, 0x0578, 0x0580, 0x056E, 0x0578, 0x0582, 0x0576, 0x0565, 0x0578, 0x0582, 0x0569, 0x0575, 0x0578, 0x0582, 0x0576, 0x0576, 0x0565, 0x0580, 0x056B, 0x20, 0x0576, 0x056F, 0x0561, 0x0580, 0x0561, 0x0563, 0x0580, 0x0578, 0x0582, 0x0569, 0x0575, 0x0578, 0x0582, 0x0576),
  },
  safety: {
    description: arm(0x0531, 0x0576, 0x057E, 0x057F, 0x0561, 0x0576, 0x0563, 0x0578, 0x0582, 0x0569, 0x0575, 0x0561, 0x0576, 0x20, 0x0576, 0x056F, 0x0561, 0x0580, 0x0561, 0x0563, 0x0580, 0x0578, 0x0582, 0x0569, 0x0575, 0x0578, 0x0582, 0x0576),
  },
  metas: {
    site_title: arm(0x053F, 0x0561, 0x0575, 0x0584, 0x056B, 0x20, 0x057E, 0x0565, 0x0580, 0x0576, 0x0561, 0x0563, 0x056B, 0x0580),
    meta_description: arm(0x0546, 0x056F, 0x0561, 0x0580, 0x0561, 0x0563, 0x0580, 0x0578, 0x0582, 0x0569, 0x0575, 0x0578, 0x0582, 0x0576),
    og_title: "OG Title",
    og_description: "OG Description",
    og_url: "OG URL",
    og_image: "OG Image URL",
  },
  kids: {
    title: arm(0x054E, 0x0565, 0x0580, 0x0576, 0x0561, 0x0563, 0x056B, 0x0580),
    description: arm(0x0546, 0x056F, 0x0561, 0x0580, 0x0561, 0x0563, 0x0580, 0x0578, 0x0582, 0x0569, 0x0575, 0x0578, 0x0582, 0x0576),
  },
};

// UI strings
const ui = {
  adminPanel: arm(0x0531, 0x0564, 0x0574, 0x056B, 0x0576, 0x20, 0x057E, 0x0561, 0x0570, 0x0561, 0x0576, 0x0561, 0x056F),
  save: arm(0x054A, 0x0561, 0x0570, 0x057A, 0x0561, 0x0576, 0x0565, 0x056C),
  exit: arm(0x0535, 0x056C, 0x0584),
  saved: arm(0x054A, 0x0561, 0x0570, 0x057A, 0x0561, 0x0576, 0x057E, 0x0561, 0x056E, 0x20, 0x0567) + "!",
  saveError: arm(0x054D, 0x056D, 0x0561, 0x056C, 0x20, 0x057A, 0x0561, 0x0570, 0x057A, 0x0561, 0x0576, 0x0565, 0x056C, 0x056B, 0x057D),
  imageDeleted: arm(0x054A, 0x0561, 0x057F, 0x056F, 0x0565, 0x0580, 0x0568, 0x20, 0x057B, 0x0576, 0x057B, 0x057E, 0x0561, 0x056E, 0x20, 0x0567) + "!",
  noChanges: arm(0x0553, 0x0578, 0x0583, 0x0578, 0x056D, 0x0578, 0x0582, 0x0569, 0x0575, 0x0578, 0x0582, 0x0576, 0x20, 0x0579, 0x056F, 0x0561),
  imageUploaded: arm(0x054A, 0x0561, 0x057F, 0x056F, 0x0565, 0x0580, 0x0568, 0x20, 0x0562, 0x0565, 0x057C, 0x0576, 0x057E, 0x0561, 0x056E, 0x20, 0x0567) + "!",
  uploadError: arm(0x054D, 0x056D, 0x0561, 0x056C, 0x20, 0x057E, 0x0565, 0x0580, 0x0562, 0x0565, 0x057C, 0x0576, 0x0565, 0x056C, 0x056B, 0x057D),
  saveChanges: arm(0x054A, 0x0561, 0x0570, 0x057A, 0x0561, 0x0576, 0x0565, 0x056C, 0x20, 0x0583, 0x0578, 0x0583, 0x0578, 0x056D, 0x0578, 0x0582, 0x0569, 0x0575, 0x0578, 0x0582, 0x0576, 0x0576, 0x0565, 0x0580, 0x0568),
  gallery: arm(0x054A, 0x0561, 0x057F, 0x056F, 0x0565, 0x0580, 0x0561, 0x057D, 0x0580, 0x0561, 0x0570),
  imagesFor: arm(0x054A, 0x0561, 0x057F, 0x056F, 0x0565, 0x0580, 0x0576, 0x0565, 0x0580) + " \u2014 ",
  uploadImages: arm(0x054E, 0x0565, 0x0580, 0x0562, 0x0565, 0x057C, 0x0576, 0x0565, 0x056C, 0x20, 0x057A, 0x0561, 0x057F, 0x056F, 0x0565, 0x0580, 0x0576, 0x0565, 0x0580),
  noImages: arm(0x054A, 0x0561, 0x057F, 0x056F, 0x0565, 0x0580, 0x0576, 0x0565, 0x0580, 0x20, 0x0564, 0x0565, 0x057C, 0x20, 0x0579, 0x056F, 0x0561, 0x0576, 0x20, 0x057E, 0x0565, 0x0580, 0x0562, 0x0565, 0x057C, 0x0576, 0x057E, 0x0561, 0x056E),
};

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { signOut } = useAuth();
  const queryClient = useQueryClient();
  const [activeSection, setActiveSection] = useState("hero");
  const [formData, setFormData] = useState<Record<string, Record<string, string>>>({});
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Fetch all content
  const { data: siteContent, isLoading: contentLoading } = useQuery({
    queryKey: ["site-content"],
    queryFn: async () => {
      const { data, error } = await supabase.from("site_content").select("*");
      if (error) throw error;
      const map: Record<string, Record<string, string>> = {};
      data?.forEach((row) => {
        map[row.section_key] = row.content as Record<string, string>;
      });
      return map;
    },
  });

  // Fetch images
  const { data: siteImages, isLoading: imagesLoading } = useQuery({
    queryKey: ["site-images", activeSection],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("site_images")
        .select("*")
        .eq("section_key", activeSection)
        .order("sort_order");
      if (error) throw error;
      return data;
    },
  });

  // Save content mutation
  const saveMutation = useMutation({
    mutationFn: async ({ key, content }: { key: string; content: Record<string, string> }) => {
      // Try update first, then upsert
      const { data: existing } = await supabase
        .from("site_content")
        .select("id")
        .eq("section_key", key)
        .single();

      if (existing) {
        const { error } = await supabase
          .from("site_content")
          .update({ content })
          .eq("section_key", key);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("site_content")
          .insert({ section_key: key, content });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["site-content"] });
      toast.success(ui.saved);
    },
    onError: () => toast.error(ui.saveError),
  });

  // Delete image mutation
  const deleteImageMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("site_images").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["site-images"] });
      toast.success(ui.imageDeleted);
    },
  });

  const getField = (section: string, field: string) => {
    return formData[section]?.[field] ?? (siteContent?.[section] as Record<string, string>)?.[field] ?? "";
  };

  const setField = (section: string, field: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [section]: { ...prev[section], ...((siteContent?.[section] as Record<string, string>) ?? {}), [field]: value },
    }));
  };

  const handleSave = () => {
    const data = formData[activeSection];
    if (!data || Object.keys(data).length === 0) {
      toast.info(ui.noChanges);
      return;
    }
    saveMutation.mutate({ key: activeSection, content: data });
  };

  const handleUploadImage = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setUploading(true);

    try {
      for (const file of Array.from(files)) {
        const ext = file.name.split(".").pop();
        const path = `${activeSection}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;

        const { error: uploadError } = await supabase.storage
          .from("site-images")
          .upload(path, file);

        if (uploadError) throw uploadError;

        const { data: urlData } = supabase.storage
          .from("site-images")
          .getPublicUrl(path);

        await supabase.from("site_images").insert({
          section_key: activeSection,
          image_url: urlData.publicUrl,
          alt_text: file.name,
        });
      }
      queryClient.invalidateQueries({ queryKey: ["site-images"] });
      toast.success(ui.imageUploaded);
    } catch (err: unknown) {
      toast.error(ui.uploadError);
      console.error(err);
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }, [activeSection, queryClient]);

  const handleLogout = async () => {
    await signOut();
    navigate("/admin");
  };

  const renderContentEditor = () => {
    const labels = fieldLabels[activeSection];
    if (!labels) return null;

    const fields = Object.entries(labels);
    return (
      <div className="space-y-4">
        {fields.map(([field, label]) => {
          const isLong = ["description", "text1", "text2", "small_group", "middle_group", "senior_group"].includes(field);
          return isLong ? (
            <FieldTextarea key={field} label={label} section={activeSection} field={field} value={getField(activeSection, field)} onChange={setField} />
          ) : (
            <Field key={field} label={label} section={activeSection} field={field} value={getField(activeSection, field)} onChange={setField} />
          );
        })}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-muted/30">
      {/* Header */}
      <header className="gradient-primary text-primary-foreground sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/")}
              className="text-primary-foreground hover:bg-primary-foreground/10"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-bold">{ui.adminPanel}</h1>
          </div>
          <div className="flex gap-2">
            <Button
              onClick={handleSave}
              disabled={saveMutation.isPending}
              className="bg-primary-foreground/20 hover:bg-primary-foreground/30 text-primary-foreground rounded-full gap-2"
            >
              {saveMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              {ui.save}
            </Button>
            <Button
              variant="ghost"
              onClick={handleLogout}
              className="text-primary-foreground hover:bg-primary-foreground/10 gap-2"
            >
              <LogOut className="h-4 w-4" />
              {ui.exit}
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-[260px_1fr] gap-6">
          {/* Sidebar */}
          <div className="space-y-1">
            {sections.map((s) => (
              <button
                key={s.id}
                onClick={() => setActiveSection(s.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left font-medium transition-colors ${
                  activeSection === s.id
                    ? "bg-primary text-primary-foreground"
                    : "text-foreground hover:bg-muted"
                }`}
              >
                <s.icon className="h-4 w-4" />
                {s.label}
              </button>
            ))}
          </div>

          {/* Content */}
          <div className="space-y-6">
            {/* Text content editor */}
            {activeSection !== "gallery" && activeSection !== "metas" && (
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {(() => {
                      const Icon = sections.find((s) => s.id === activeSection)!.icon;
                      return <Icon className="h-5 w-5 text-primary" />;
                    })()}
                    {sections.find((s) => s.id === activeSection)?.label}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {contentLoading ? (
                    <div className="flex justify-center py-8">
                      <Loader2 className="h-6 w-6 animate-spin text-primary" />
                    </div>
                  ) : (
                    renderContentEditor()
                  )}
                  <Button
                    onClick={handleSave}
                    disabled={saveMutation.isPending}
                    className="gradient-primary text-primary-foreground rounded-full gap-2 hover:opacity-90"
                  >
                    {saveMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                    {ui.saveChanges}
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Kids management */}
            {activeSection === "kids" && <KidsSection />}

            {/* Metas editor */}
            {activeSection === "metas" && (
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5 text-primary" />
                    SEO / Meta
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {contentLoading ? (
                    <div className="flex justify-center py-8">
                      <Loader2 className="h-6 w-6 animate-spin text-primary" />
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {Object.entries(fieldLabels.metas).map(([field, label]) => (
                        <Field key={field} label={label} section="metas" field={field} value={getField("metas", field)} onChange={setField} />
                      ))}
                    </div>
                  )}
                  <Button
                    onClick={handleSave}
                    disabled={saveMutation.isPending}
                    className="gradient-primary text-primary-foreground rounded-full gap-2 hover:opacity-90"
                  >
                    {saveMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                    {ui.saveChanges}
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Image uploader for all sections */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ImageIcon className="h-5 w-5 text-primary" />
                  {activeSection === "gallery"
                    ? ui.gallery
                    : ui.imagesFor + sections.find((s) => s.id === activeSection)?.label}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  onChange={handleUploadImage}
                />
                <Button
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploading}
                  className="w-full border-dashed border-2 h-24 gap-2 text-muted-foreground hover:text-primary hover:border-primary"
                >
                  {uploading ? (
                    <Loader2 className="h-5 w-5 animate-spin" />
                  ) : (
                    <>
                      <Plus className="h-5 w-5" />
                      {ui.uploadImages}
                    </>
                  )}
                </Button>

                {imagesLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : siteImages && siteImages.length > 0 ? (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-4">
                    {siteImages.map((img) => (
                      <div key={img.id} className="relative group rounded-xl overflow-hidden border bg-muted/50">
                        <img
                          src={img.image_url}
                          alt={img.alt_text || ""}
                          className="w-full h-32 object-cover"
                        />
                        <Button
                          variant="destructive"
                          size="icon"
                          className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8"
                          onClick={() => deleteImageMutation.mutate(img.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground text-sm mt-4">
                    {ui.noImages}
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

// Reusable form field components
function Field({ label, section, field, value, onChange }: {
  label: string; section: string; field: string; value: string;
  onChange: (section: string, field: string, value: string) => void;
}) {
  return (
    <div>
      <label className="text-sm font-medium text-foreground mb-2 block">{label}</label>
      <Input value={value} onChange={(e) => onChange(section, field, e.target.value)} />
    </div>
  );
}

function FieldTextarea({ label, section, field, value, onChange }: {
  label: string; section: string; field: string; value: string;
  onChange: (section: string, field: string, value: string) => void;
}) {
  return (
    <div>
      <label className="text-sm font-medium text-foreground mb-2 block">{label}</label>
      <Textarea rows={4} value={value} onChange={(e) => onChange(section, field, e.target.value)} />
    </div>
  );
}

export default AdminDashboard;
