import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { GraduationCap, Lock, Mail, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";

const arm = (...codes: number[]) => String.fromCharCode(...codes);

const loginUi = {
  adminLogin: arm(0x0531, 0x0564, 0x0574, 0x056B, 0x0576, 0x20, 0x0574, 0x0578, 0x0582, 0x057F, 0x0584),
  loginSubtitle: arm(0x0544, 0x0578, 0x0582, 0x057F, 0x0584, 0x20, 0x0563, 0x0578, 0x0580, 0x056E, 0x0565, 0x0584, 0x20, 0x056F, 0x0561, 0x0575, 0x0584, 0x056B, 0x20, 0x056F, 0x0561, 0x057C, 0x0561, 0x057E, 0x0561, 0x0580, 0x0574, 0x0561, 0x0576, 0x20, 0x057E, 0x0561, 0x0570, 0x0561, 0x0576, 0x0561, 0x056F, 0x056B, 0x0576),
  emailPlaceholder: arm(0x0537, 0x056C, 0x002E, 0x20, 0x0583, 0x0578, 0x057D, 0x057F),
  passwordPlaceholder: arm(0x0533, 0x0561, 0x0572, 0x057F, 0x0576, 0x0561, 0x0562, 0x0561, 0x057C),
  loginButton: arm(0x0544, 0x0578, 0x0582, 0x057F, 0x0584, 0x20, 0x0563, 0x0578, 0x0580, 0x056E, 0x0565, 0x056C),
  loginError: arm(0x054D, 0x056D, 0x0561, 0x056C, 0x20, 0x0574, 0x0578, 0x0582, 0x057F, 0x0584, 0x0561, 0x0576, 0x0578, 0x0582, 0x0576, 0x20, 0x056F, 0x0561, 0x0574, 0x20, 0x0563, 0x0561, 0x0572, 0x057F, 0x0576, 0x0561, 0x0562, 0x0561, 0x057C),
  loginSuccess: arm(0x0540, 0x0561, 0x057B, 0x0578, 0x0572, 0x057E, 0x0561, 0x056E, 0x20, 0x0574, 0x0578, 0x0582, 0x057F, 0x0584, 0x20, 0x0567, 0x20, 0x0563, 0x0578, 0x0580, 0x056E, 0x057E, 0x0565, 0x056C) + "!",
  backToHome: "\u2190 " + arm(0x054E, 0x0565, 0x0580, 0x0561, 0x0564, 0x0561, 0x057C, 0x0576, 0x0561, 0x056C, 0x20, 0x0563, 0x056C, 0x056D, 0x0561, 0x057E, 0x0578, 0x0580, 0x20, 0x0567, 0x057B),
};

const AdminLogin = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { user, isAdmin, loading, signIn } = useAuth();

  useEffect(() => {
    if (!loading && user && isAdmin) {
      navigate("/admin/dashboard", { replace: true });
    }
  }, [user, isAdmin, loading, navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    const { error } = await signIn(email, password);

    if (error) {
      toast.error(loginUi.loginError);
      setIsLoading(false);
      return;
    }

    toast.success(loginUi.loginSuccess);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/50 px-4">
      <Card className="w-full max-w-md card-shadow border-0">
        <CardContent className="p-8">
          <div className="text-center mb-8">
            <div className="w-16 h-16 rounded-full bg-hero-gradient flex items-center justify-center mx-auto mb-4">
              <GraduationCap className="h-8 w-8 text-primary-foreground" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">
              {loginUi.adminLogin}
            </h1>
            <p className="text-muted-foreground mt-2">
              {loginUi.loginSubtitle}
            </p>
          </div>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="relative">
              <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                type="email"
                placeholder={loginUi.emailPlaceholder}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-10 bg-muted/50"
                required
              />
            </div>
            <div className="relative">
              <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                type="password"
                placeholder={loginUi.passwordPlaceholder}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-10 bg-muted/50"
                required
              />
            </div>
            <Button
              type="submit"
              disabled={isLoading}
              className="w-full bg-hero-gradient text-primary-foreground hover:opacity-90 rounded-full"
            >
              {isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                loginUi.loginButton
              )}
            </Button>
          </form>
          <div className="mt-6 text-center">
            <Button variant="ghost" onClick={() => navigate("/")} className="text-muted-foreground hover:text-primary">
              {loginUi.backToHome}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminLogin;
