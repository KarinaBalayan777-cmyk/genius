
-- Kids table
CREATE TABLE public.kids (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  birth_date date,
  parent_name text,
  parent_phone text,
  group_name text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.kids ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can read kids" ON public.kids FOR SELECT USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can insert kids" ON public.kids FOR INSERT WITH CHECK (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update kids" ON public.kids FOR UPDATE USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete kids" ON public.kids FOR DELETE USING (has_role(auth.uid(), 'admin'));

-- Kid payments table
CREATE TABLE public.kid_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kid_id uuid REFERENCES public.kids(id) ON DELETE CASCADE NOT NULL,
  month integer NOT NULL CHECK (month >= 1 AND month <= 12),
  year integer NOT NULL,
  is_paid boolean NOT NULL DEFAULT false,
  paid_at timestamptz,
  amount numeric,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(kid_id, month, year)
);

ALTER TABLE public.kid_payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can read kid_payments" ON public.kid_payments FOR SELECT USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can insert kid_payments" ON public.kid_payments FOR INSERT WITH CHECK (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update kid_payments" ON public.kid_payments FOR UPDATE USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete kid_payments" ON public.kid_payments FOR DELETE USING (has_role(auth.uid(), 'admin'));
